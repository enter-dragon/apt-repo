# UCM for Intel Apollolake chromebooks using SOF.

* sof-bxtda7219max: Copied and renamed from [glk](https://github.com/eupnea-linux/ucm-configs/tree/main/glk/sof-glkda7219ma).
